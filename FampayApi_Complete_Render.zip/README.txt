FampayApi complete Render files

Files:
- app.py
- requirements.txt

Render:
Build command: pip install -r requirements.txt
Start command: gunicorn --workers 1 app:app

Optional environment variable:
FAMPAY_UPI=your-upi-id

Endpoints:
GET /
GET /health
POST /create_key
POST /register_key
GET or POST /fam_create
GET or POST /fam_verify

IMPORTANT:
This is a starter/demo implementation. It stores Gmail App Passwords and API keys in local JSON files in plaintext. Render's ordinary filesystem may be ephemeral unless persistent storage is configured. The Gmail parser is heuristic; email matching is not authoritative proof of payment. For real-money production, use a trusted provider/bank verification API, secure secret storage, a persistent database, rate limiting, and proper security review.
